if CLIENT then
    hook.Add("AddToolMenuTabs", "ZombieSurvivalCreateTabs", function()
        spawnmenu.AddToolTab("Zombies", "Zombies", "icon16/user.png")
    end)

    hook.Add("PopulateToolMenu", "ZombieSurvivalPopulateMenus", function()
        spawnmenu.AddToolMenuOption("Zombies", "ZombieSurvival", "ZombieSurvivalMenu", "Menu", "", "", function(panel)
            panel:ClearControls()

            panel:AddControl("Button", {
                Label = "Start Zombie Survival",
                Command = "zombie_survival_start"
            })

            panel:AddControl("Button", {
                Label = "End Zombie Survival",
                Command = "zombie_survival_end"
            })
        end)
    end)
end
