if SERVER then
    util.AddNetworkString("PlaySound")
    util.AddNetworkString("ZombieSurvivalStart")
    util.AddNetworkString("ZombieSurvivalEnd")

    local waveNumber = 0
    local totalEnemies = 0
    local enemiesRemaining = 0
    local isZombieSurvivalActive = false

    local function PlaySoundForAll(soundPath)
        print("Playing sound: " .. soundPath)  -- Debug print
        for _, ply in ipairs(player.GetAll()) do
            ply:EmitSound(soundPath, 75, 100, 1, CHAN_AUTO)  -- Emit sound at full volume
        end
    end

    local function IsSpawnPointClear(spawnPos)
        local trace = util.TraceHull({
            start = spawnPos,
            endpos = spawnPos,
            mins = Vector(-16, -16, 0),
            maxs = Vector(16, 16, 72),
            mask = MASK_SOLID
        })
        return not trace.Hit
    end

    local function GetValidSpawnPosition(ply)
        local spawnDistance = 1000 -- Distance from the player where zombies will spawn
        local attempts = 10
        while attempts > 0 do
            local angle = math.random() * math.pi * 2
            local spawnPos = ply:GetPos() + Vector(math.cos(angle) * spawnDistance, math.sin(angle) * spawnDistance, 0)
            if IsSpawnPointClear(spawnPos) then
                return spawnPos
            end
            attempts = attempts - 1
        end
        return nil
    end

    local function SpawnEnemy(enemyClass, ply)
        local spawnPos = GetValidSpawnPosition(ply)
        if not spawnPos then return end

        local enemy = ents.Create(enemyClass)
        if IsValid(enemy) then
            enemy:SetPos(spawnPos)
            enemy:Spawn()
            enemy:SetTarget(ply)
            enemy:SetKeyValue("target", ply:GetName()) -- Make the zombie target the player
            enemy:AddRelationship("player D_HT 99") -- Ensure the zombie hates the player

            -- Make zombies break doors
            enemy:SetKeyValue("breakabledoors", 1)

            -- Set up door-breaking
            enemy:Input("SetRelationship", nil, nil, "npc_door D_HT 99")

            -- Make zombies always know where the player is
            local bullseye = ents.Create("npc_bullseye")
            bullseye:SetPos(ply:GetPos())
            bullseye:SetParent(ply)
            bullseye:Spawn()
            bullseye:SetNoDraw(true)
            bullseye:SetSolid(SOLID_NONE)
            enemy:SetTarget(bullseye)
            
            enemy:CallOnRemove("EnemyKilled", function()
                if IsValid(bullseye) then bullseye:Remove() end
                enemiesRemaining = enemiesRemaining - 1
                if enemiesRemaining <= 0 and isZombieSurvivalActive then
                    PlaySoundForAll("zombies/start_wave.mp3")
                    timer.Simple(5, StartNextWave)
                end
            end)
        end
    end

    local function StartNextWave()
        if not isZombieSurvivalActive then return end

        waveNumber = waveNumber + 1
        totalEnemies = 30
        enemiesRemaining = totalEnemies

        print("Starting wave " .. waveNumber)  -- Debug print
        PlaySoundForAll("zombies/start_wave.mp3")

        for _, ply in ipairs(player.GetAll()) do
            if ply:Alive() then
                for i = 1, 10 do
                    SpawnEnemy("npc_zombie", ply)
                    SpawnEnemy("npc_fastzombie", ply)
                    SpawnEnemy("npc_poisonzombie", ply)
                end
            end
        end
    end

    local function StartZombieSurvival()
        print("Starting Zombie Survival")  -- Debug print
        waveNumber = 0
        isZombieSurvivalActive = true
        StartNextWave()
    end

    local function EndZombieSurvival()
        print("Ending Zombie Survival")  -- Debug print
        isZombieSurvivalActive = false
        waveNumber = 0
        enemiesRemaining = 0
        for _, v in pairs(ents.FindByClass("npc_zombie")) do
            v:Remove()
        end
        for _, v in pairs(ents.FindByClass("npc_fastzombie")) do
            v:Remove()
        end
        for _, v in pairs(ents.FindByClass("npc_poisonzombie")) do
            v:Remove()
        end
        PlaySoundForAll("zombies/end_wave.mp3")
    end

    concommand.Add("zombie_survival_start", function(ply, cmd, args)
        if IsValid(ply) and ply:IsAdmin() then
            StartZombieSurvival()
        else
            print("Only admins can start the zombie survival mode.")
        end
    end)

    concommand.Add("zombie_survival_end", function(ply, cmd, args)
        if IsValid(ply) and ply:IsAdmin() then
            EndZombieSurvival()
        else
            print("Only admins can end the zombie survival mode.")
        end
    end)
end
