if CLIENT then
    net.Receive("PlaySound", function()
        local soundPath = net.ReadString()
        print("Received sound to play: " .. soundPath)  -- Debug print
        surface.PlaySound(soundPath)
    end)
end
